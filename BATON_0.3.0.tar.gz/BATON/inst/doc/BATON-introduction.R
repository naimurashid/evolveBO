## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)

## ----eval=FALSE---------------------------------------------------------------
# # Install from GitHub
# devtools::install_github("naimurashid/BATON")

## -----------------------------------------------------------------------------
library(BATON)

## -----------------------------------------------------------------------------
# Simple simulator for demonstration
simple_simulator <- function(theta, fidelity = c("low", "med", "high"), seed = NULL, ...) {
  fidelity <- match.arg(fidelity)

  # Number of Monte Carlo replications by fidelity
  n_rep <- switch(fidelity,
                  low = 200,
                  med = 1000,
                  high = 10000)

  if (!is.null(seed)) set.seed(seed)

  # Extract design parameters
  threshold <- theta$threshold
  alpha <- theta$alpha

  # Simulate trials (simplified example)
  power_vec <- numeric(n_rep)
  type1_vec <- numeric(n_rep)
  sample_size_vec <- numeric(n_rep)

  for (i in 1:n_rep) {
    # Simulate test statistic under alternative
    test_stat <- rnorm(1, mean = threshold, sd = 1)
    power_vec[i] <- as.numeric(abs(test_stat) > qnorm(1 - alpha/2))

    # Type I error (under null)
    test_stat_null <- rnorm(1, mean = 0, sd = 1)
    type1_vec[i] <- as.numeric(abs(test_stat_null) > qnorm(1 - alpha/2))

    # Sample size
    sample_size_vec[i] <- rpois(1, lambda = 100)
  }

  # Compute means
  metrics <- c(
    power = mean(power_vec),
    type1 = mean(type1_vec),
    EN = mean(sample_size_vec),
    ET = mean(sample_size_vec) / 10  # Expected duration
  )

  # IMPORTANT: Compute and attach variance
  variance <- c(
    power = var(power_vec) / n_rep,
    type1 = var(type1_vec) / n_rep,
    EN = var(sample_size_vec) / n_rep,
    ET = var(sample_size_vec / 10) / n_rep
  )

  attr(metrics, "variance") <- variance
  attr(metrics, "n_rep") <- n_rep

  return(metrics)
}

## -----------------------------------------------------------------------------
# Test with some parameters
test_result <- simple_simulator(
  theta = list(threshold = 2.0, alpha = 0.025),
  fidelity = "low",
  seed = 123
)

print(test_result)
print(attr(test_result, "variance"))

## -----------------------------------------------------------------------------
# Parameter bounds
bounds <- list(
  threshold = c(1.5, 3.0),  # Effect size threshold
  alpha = c(0.01, 0.05)     # Significance level
)

# Objective: minimize expected sample size
objective <- "EN"

# Constraints: power ≥ 0.8, type I error ≤ 0.05
constraints <- list(
  power = c("ge", 0.8),
  type1 = c("le", 0.05)
)

## ----eval=FALSE---------------------------------------------------------------
# # Run calibration
# fit <- bo_calibrate(
#   sim_fun = simple_simulator,
#   bounds = bounds,
#   objective = objective,
#   constraints = constraints,
#   n_init = 10,      # Initial LHS design points
#   q = 2,            # Batch size per iteration
#   budget = 30,      # Total evaluations
#   seed = 2025
# )

## ----echo=FALSE---------------------------------------------------------------
# For vignette building, use smaller budget
fit <- bo_calibrate(
  sim_fun = simple_simulator,
  bounds = bounds,
  objective = objective,
  constraints = constraints,
  n_init = 8,
  q = 2,
  budget = 20,
  seed = 2025,
  progress = FALSE
)

## -----------------------------------------------------------------------------
# Best design parameters
print(fit$best_theta)

# Operating characteristics at best design
best_idx <- which.min(fit$history$objective[fit$history$feasible])
print(fit$history$metrics[[best_idx]])

# Optimization history
head(fit$history[, c("iter", "fidelity", "objective", "feasible")])

## -----------------------------------------------------------------------------
# RECOMMENDED: Memory-efficient simulator using Welford's algorithm
efficient_simulator <- function(theta, fidelity = "high", seed = NULL, ...) {
  n_rep <- switch(fidelity,
                  low = 200,
                  med = 1000,
                  high = 10000)

  if (!is.null(seed)) set.seed(seed)

  # Use Welford's algorithm - no need to store all samples!
  result <- welford_mean_var(
    sample_fn = function(i, theta) {
      # Simulate ONE trial
      test_stat <- rnorm(1, mean = theta$threshold, sd = 1)
      power <- as.numeric(abs(test_stat) > qnorm(1 - theta$alpha/2))

      test_stat_null <- rnorm(1, mean = 0, sd = 1)
      type1 <- as.numeric(abs(test_stat_null) > qnorm(1 - theta$alpha/2))

      sample_size <- rpois(1, lambda = 100)

      c(power = power,
        type1 = type1,
        EN = sample_size,
        ET = sample_size / 10)
    },
    n_samples = n_rep,
    theta = theta
  )

  # Extract results
  metrics <- result$mean
  attr(metrics, "variance") <- result$variance
  attr(metrics, "n_rep") <- result$n

  return(metrics)
}

## -----------------------------------------------------------------------------
# Traditional approach (storing all samples)
traditional_memory <- function(n_rep, n_metrics) {
  8 * n_rep * n_metrics  # bytes
}

# Welford approach (incremental)
welford_memory <- function(n_metrics) {
  8 * 2 * n_metrics  # bytes (just mean and M2 vectors)
}

# For n_rep = 10,000 and 4 metrics:
cat("Traditional: ", traditional_memory(10000, 4) / 1024, "KB\n")
cat("Welford:     ", welford_memory(4), "bytes\n")
cat("Reduction:   ", traditional_memory(10000, 4) / welford_memory(4), "x\n")

## ----eval=FALSE---------------------------------------------------------------
# parallel_simulator <- function(theta, fidelity = "high", n_cores = 4, ...) {
#   n_rep <- switch(fidelity, low = 200, med = 1000, high = 10000)
#   chunk_size <- ceiling(n_rep / n_cores)
# 
#   # Run chunks in parallel
#   library(parallel)
#   chunks <- mclapply(1:n_cores, function(core_id) {
#     welford_mean_var(
#       sample_fn = function(i, theta) {
#         # Your trial simulation here
#         c(power = ..., EN = ...)
#       },
#       n_samples = chunk_size,
#       theta = theta
#     )
#   }, mc.cores = n_cores)
# 
#   # Pool results using Chan's algorithm
#   pooled <- pool_welford_results(chunks)
# 
#   metrics <- pooled$mean
#   attr(metrics, "variance") <- pooled$variance
#   attr(metrics, "n_rep") <- pooled$n
# 
#   return(metrics)
# }

## -----------------------------------------------------------------------------
# Examine fidelity allocation
table(fit$history$fidelity)

# Total simulation budget used
sum(fit$history$n_rep)

## ----eval=FALSE---------------------------------------------------------------
# fit_custom <- bo_calibrate(
#   sim_fun = simple_simulator,
#   bounds = bounds,
#   objective = objective,
#   constraints = constraints,
#   # Custom fidelity levels
#   fidelity_levels = c(
#     low = 100,
#     med = 500,
#     high = 5000
#   ),
#   n_init = 10,
#   budget = 50
# )

## ----eval=FALSE---------------------------------------------------------------
# benchmark <- benchmark_methods(
#   sim_fun = simple_simulator,
#   bounds = bounds,
#   objective = objective,
#   constraints = constraints,
#   strategies = c("bo", "random", "grid"),
#   bo_args = list(n_init = 10, q = 2, budget = 30, seeds = 1:3),
#   random_args = list(n_samples = 30, seeds = 1:3),
#   grid_args = list(resolution = list(threshold = 5, alpha = 5))
# )
# 
# # Summary statistics
# summary_tbl <- summarise_benchmark(benchmark)
# print(summary_tbl)
# 
# # Visualization
# plot_benchmark_trajectory(benchmark)
# plot_benchmark_efficiency(benchmark)

## ----eval=FALSE---------------------------------------------------------------
# # Sobol sensitivity indices
# sobol <- sa_sobol(
#   surrogates = fit$surrogates,
#   bounds = bounds,
#   outcome = "EN",
#   n_mc = 2000
# )
# 
# print(sobol)
# plot_sobol_indices(sobol)
# 
# # Local gradients
# gradients <- sa_gradients(
#   surrogates = fit$surrogates,
#   theta = fit$best_theta,
#   bounds = bounds,
#   outcome = "EN"
# )
# 
# print(gradients)
# 
# # Gradient covariance across design space
# cov_matrix <- cov_effects(
#   surrogates = fit$surrogates,
#   bounds = bounds,
#   outcome = "EN",
#   n_mc = 500
# )
# 
# print(cov_matrix)

## ----eval=FALSE---------------------------------------------------------------
# reliability <- estimate_constraint_reliability(
#   sim_fun = simple_simulator,
#   bounds = bounds,
#   objective = objective,
#   constraints = constraints,
#   strategies = c("bo", "random"),
#   calibration_seeds = 1:10,
#   validation_reps = 50000,  # Large sample validation
#   bo_args = list(n_init = 10, budget = 30)
# )
# 
# print(reliability$summary)
# plot_constraint_reliability(reliability)

## ----eval=FALSE---------------------------------------------------------------
# ablation <- ablation_multifidelity(
#   sim_fun = simple_simulator,
#   bounds = bounds,
#   objective = objective,
#   constraints = constraints,
#   policies = list(
#     low_only = c(low = 200),
#     med_only = c(med = 1000),
#     full = c(low = 200, med = 1000, high = 10000)
#   ),
#   seeds = 1:10,
#   bo_args = list(n_init = 10, budget = 30)
# )
# 
# print(ablation$summary)
# plot_multifidelity_tradeoff(ablation)

## ----eval=FALSE---------------------------------------------------------------
# # Summarize calibrated design
# summary <- summarise_case_study(fit)
# print(summary$design)
# print(summary$operating_characteristics)
# 
# # Comprehensive diagnostics
# diagnostics <- case_study_diagnostics(
#   fit,
#   sobol_samples = 5000,
#   gradient_points = 200
# )
# 
# # Visualizations
# plot_feasible_frontier(fit)
# plot_tradeoff_surfaces(fit)
# plot_case_sobol(diagnostics$sobol)
# plot_case_gradient(diagnostics$gradients)
# plot_case_covariance(diagnostics$covariance)

## -----------------------------------------------------------------------------
sessionInfo()

