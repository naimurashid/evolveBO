## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)

## ----load-package, eval=FALSE-------------------------------------------------
# library(BATON)
# library(ggplot2)
# library(dplyr)

## ----toy-simulator, eval=FALSE------------------------------------------------
# toy_simulator <- function(theta, fidelity = "high", seed = NULL, ...) {
#   n_rep <- switch(fidelity,
#     low = 200,
#     med = 1000,
#     high = 10000
#   )
# 
#   # Use Welford's algorithm for variance estimation
#   result <- welford_mean_var(
#     sample_fn = function(i, theta) {
#       # Simulate trial outcomes
#       threshold <- theta$threshold
#       alpha <- theta$alpha
# 
#       # Operating characteristics (simplified)
#       power <- plogis((threshold - 2.0) / 0.3 + rnorm(1, 0, 0.1))
#       type1 <- plogis((alpha - 0.03) / 0.01 + rnorm(1, 0, 0.1))
#       EN <- 100 + (threshold - 2.0)^2 * 50 + rnorm(1, 0, 5)
# 
#       c(power = power, type1 = type1, EN = EN)
#     },
#     n_samples = n_rep,
#     theta = theta
#   )
# 
#   metrics <- result$mean
#   attr(metrics, "variance") <- result$variance
#   attr(metrics, "n_rep") <- n_rep
# 
#   return(metrics)
# }
# 
# # Design space
# bounds <- list(
#   threshold = c(1.5, 3.0),
#   alpha = c(0.01, 0.05)
# )
# 
# # Constraints
# constraints <- list(
#   power = c("ge", 0.8),    # Power ≥ 0.8
#   type1 = c("le", 0.05)     # Type I error ≤ 0.05
# )

## ----batch-diversity-example, eval=FALSE--------------------------------------
# # Without diversity (greedy selection) - not recommended
# # This would cluster points in the same high-acquisition region
# 
# # With diversity (local penalization) - default in v0.3.0
# fit <- bo_calibrate(
#   sim_fun = toy_simulator,
#   bounds = bounds,
#   objective = "EN",
#   constraints = constraints,
#   n_init = 10,
#   q = 2,  # Batch of 2 points per iteration
#   budget = 40,
#   seed = 2025
# )

## ----plot-batch-diversity, eval=FALSE-----------------------------------------
# # Extract batch iterations (iter > 0, group by iter)
# batch_points <- fit$history %>%
#   filter(iter > 0) %>%
#   group_by(iter) %>%
#   mutate(batch_id = cur_group_id()) %>%
#   ungroup()
# 
# # Plot first few batches
# first_batches <- batch_points %>% filter(batch_id <= 5)
# 
# ggplot(first_batches, aes(x = theta[[1]]$threshold, y = theta[[1]]$alpha)) +
#   geom_point(aes(color = factor(batch_id)), size = 3) +
#   facet_wrap(~batch_id, ncol = 5) +
#   labs(
#     title = "Batch Diversity via Local Penalization",
#     subtitle = "Each facet shows one batch of 4 points",
#     x = "Threshold",
#     y = "Alpha",
#     color = "Batch"
#   ) +
#   theme_minimal()

## ----fidelity-methods, eval=FALSE---------------------------------------------
# # 1. Adaptive (RECOMMENDED) - cost-aware value-per-cost optimization
# fit_adaptive <- bo_calibrate(
#   sim_fun = toy_simulator,
#   bounds = bounds,
#   objective = "EN",
#   constraints = constraints,
#   fidelity_method = "adaptive",  # Default in v0.3.0
#   budget = 50
# )
# 
# # 2. Staged - simple iteration-based thresholds
# fit_staged <- bo_calibrate(
#   sim_fun = toy_simulator,
#   bounds = bounds,
#   objective = "EN",
#   constraints = constraints,
#   fidelity_method = "staged",
#   budget = 50
# )
# 
# # 3. Threshold - legacy feasibility probability thresholds
# fit_threshold <- bo_calibrate(
#   sim_fun = toy_simulator,
#   bounds = bounds,
#   objective = "EN",
#   constraints = constraints,
#   fidelity_method = "threshold",
#   budget = 50
# )

## ----custom-costs, eval=FALSE-------------------------------------------------
# # Scenario: High-fidelity has setup overhead
# # Instead of linear 1:5:50, costs are 1:3:20
# fit_custom <- bo_calibrate(
#   sim_fun = toy_simulator,
#   bounds = bounds,
#   objective = "EN",
#   constraints = constraints,
#   fidelity_method = "adaptive",
#   fidelity_levels = c(low = 200, med = 1000, high = 10000),
#   fidelity_costs = c(low = 1, med = 3, high = 20),  # Custom costs
#   budget = 50
# )

## ----compare-fidelity-methods, eval=FALSE-------------------------------------
# # Run all three methods with same seed
# set.seed(42)
# fit_adaptive <- bo_calibrate(..., fidelity_method = "adaptive", budget = 50)
# 
# set.seed(42)
# fit_staged <- bo_calibrate(..., fidelity_method = "staged", budget = 50)
# 
# set.seed(42)
# fit_threshold <- bo_calibrate(..., fidelity_method = "threshold", budget = 50)
# 
# # Compare final objective values
# tibble(
#   method = c("Adaptive", "Staged", "Threshold"),
#   best_objective = c(
#     min(fit_adaptive$history$objective[fit_adaptive$history$feasible]),
#     min(fit_staged$history$objective[fit_staged$history$feasible]),
#     min(fit_threshold$history$objective[fit_threshold$history$feasible])
#   ),
#   evaluations = c(
#     nrow(fit_adaptive$history),
#     nrow(fit_staged$history),
#     nrow(fit_threshold$history)
#   )
# )

## ----plot-fidelity, eval=FALSE------------------------------------------------
# # Plot fidelity choices over iterations
# fit_adaptive$history %>%
#   ggplot(aes(x = iter, fill = fidelity)) +
#   geom_bar(position = "stack") +
#   labs(
#     title = "Adaptive Fidelity Selection Over Time",
#     subtitle = "Early iterations use low/med, later iterations use high",
#     x = "Iteration",
#     y = "Count",
#     fill = "Fidelity"
#   ) +
#   theme_minimal()
# 
# # Compare fidelity distribution across methods
# bind_rows(
#   fit_adaptive$history %>% mutate(method = "Adaptive"),
#   fit_staged$history %>% mutate(method = "Staged"),
#   fit_threshold$history %>% mutate(method = "Threshold")
# ) %>%
#   ggplot(aes(x = fidelity, fill = method)) +
#   geom_bar(position = "dodge") +
#   labs(
#     title = "Fidelity Distribution by Method",
#     x = "Fidelity Level",
#     y = "Count",
#     fill = "Method"
#   ) +
#   theme_minimal()

## ----warm-start-example, eval=FALSE-------------------------------------------
# # Warm-start is automatic in v0.3.0
# fit <- bo_calibrate(
#   sim_fun = toy_simulator,
#   bounds = bounds,
#   objective = "EN",
#   constraints = constraints,
#   budget = 50
# )
# # Internally, GP hyperparameters are warm-started from iteration 2 onward

## ----adaptive-pool-example, eval=FALSE----------------------------------------
# # For 2D problem: pool = 1000 (early), 1500 (late)
# # For 5D problem: pool = 2500 (early), 3750 (late)
# # For 10D problem: pool = 5000 (early), 7500 (late)
# 
# fit <- bo_calibrate(
#   sim_fun = toy_simulator,
#   bounds = bounds,  # 2D problem
#   objective = "EN",
#   constraints = constraints,
#   budget = 50
# )
# # Pool size automatically determined based on dimensionality

## ----early-stopping-example, eval=FALSE---------------------------------------
# # Early stopping is automatic in v0.3.0
# fit <- bo_calibrate(
#   sim_fun = toy_simulator,
#   bounds = bounds,
#   objective = "EN",
#   constraints = constraints,
#   budget = 100  # May stop before reaching 100
# )
# 
# # Check if early stopping occurred
# if (nrow(fit$history) < 100) {
#   message("Early stopping triggered at iteration ", max(fit$history$iter))
# }

## ----plot-convergence, eval=FALSE---------------------------------------------
# # Plot objective value over iterations
# fit$history %>%
#   filter(feasible) %>%
#   mutate(best_so_far = cummin(objective)) %>%
#   ggplot(aes(x = iter)) +
#   geom_line(aes(y = objective), alpha = 0.3) +
#   geom_line(aes(y = best_so_far), color = "blue", size = 1) +
#   labs(
#     title = "Convergence History",
#     subtitle = "Early stopping when improvement plateaus",
#     x = "Iteration",
#     y = "Objective Value (EN)"
#   ) +
#   theme_minimal()

## ----infeasible-example, eval=FALSE-------------------------------------------
# # Problem with tight constraints (initially infeasible)
# tight_constraints <- list(
#   power = c("ge", 0.95),   # Very high power requirement
#   type1 = c("le", 0.025)   # Very low type I error
# )
# 
# fit <- bo_calibrate(
#   sim_fun = toy_simulator,
#   bounds = bounds,
#   objective = "EN",
#   constraints = tight_constraints,  # Difficult constraints
#   budget = 60
# )
# 
# # Track feasibility over time
# fit$history %>%
#   mutate(iter_group = cut(iter, breaks = seq(0, max(iter), by = 10))) %>%
#   group_by(iter_group) %>%
#   summarize(
#     feasibility_rate = mean(feasible),
#     .groups = "drop"
#   )

## ----complete-example, eval=FALSE---------------------------------------------
# library(BATON)
# 
# # Define simulator with variance estimation
# my_simulator <- function(theta, fidelity = "high", seed = NULL, ...) {
#   n_rep <- switch(fidelity,
#     low = 200,
#     med = 1000,
#     high = 10000
#   )
# 
#   result <- welford_mean_var(
#     sample_fn = function(i, theta) {
#       # Your trial simulation here
#       # Return c(power = ..., type1 = ..., EN = ...)
#     },
#     n_samples = n_rep,
#     theta = theta
#   )
# 
#   metrics <- result$mean
#   attr(metrics, "variance") <- result$variance
#   attr(metrics, "n_rep") <- n_rep
# 
#   return(metrics)
# }
# 
# # Optimization with all new features
# fit <- bo_calibrate(
#   sim_fun = my_simulator,
#   bounds = list(
#     threshold = c(1.5, 3.0),
#     alpha = c(0.01, 0.05)
#   ),
#   objective = "EN",
#   constraints = list(
#     power = c("ge", 0.8),
#     type1 = c("le", 0.05)
#   ),
# 
#   # v0.3.0 Features (all automatic)
#   n_init = 10,
#   q = 2,  # Batch size
#   budget = 50,  # Early stopping may use less
#   fidelity_method = "adaptive",  # Cost-aware fidelity
# 
#   # Optional: Custom fidelity costs
#   fidelity_costs = c(low = 1, med = 3, high = 20),
# 
#   seed = 2025,
#   progress = TRUE
# )
# 
# # Inspect results
# print(fit$best_theta)
# 
# # Check if early stopping occurred
# message(sprintf(
#   "Evaluations used: %d / %d (%.1f%%)",
#   nrow(fit$history),
#   50,
#   100 * nrow(fit$history) / 50
# ))
# 
# # Visualize fidelity choices
# table(fit$history$fidelity)
# 
# # Plot convergence
# library(ggplot2)
# fit$history %>%
#   filter(feasible) %>%
#   mutate(best_so_far = cummin(objective)) %>%
#   ggplot(aes(x = eval_id, y = best_so_far)) +
#   geom_line(size = 1, color = "blue") +
#   geom_point(aes(color = fidelity), size = 2) +
#   labs(
#     title = "Optimization Progress",
#     subtitle = sprintf("Final: EN = %.1f", fit$best_theta$objective),
#     x = "Evaluation",
#     y = "Best Objective (EN)",
#     color = "Fidelity"
#   ) +
#   theme_minimal()

## ----benchmark-example, eval=FALSE--------------------------------------------
# library(tictoc)
# 
# # Baseline (v0.2.0 equivalent)
# tic("v0.2.0 equivalent")
# fit_old <- bo_calibrate(
#   sim_fun = toy_simulator,
#   bounds = bounds,
#   objective = "EN",
#   constraints = constraints,
#   fidelity_method = "staged",
#   q = 1,  # No batch diversity
#   budget = 100  # No early stopping
# )
# time_old <- toc()
# 
# # New (v0.3.0)
# tic("v0.3.0")
# fit_new <- bo_calibrate(
#   sim_fun = toy_simulator,
#   bounds = bounds,
#   objective = "EN",
#   constraints = constraints,
#   fidelity_method = "adaptive",
#   q = 2,  # Batch size
#   budget = 100  # May stop early
# )
# time_new <- toc()
# 
# # Compare
# speedup <- (time_old$toc - time_old$tic) / (time_new$toc - time_new$tic)
# message(sprintf("Speedup: %.1fx faster", speedup))
# 
# # Compare solution quality
# message(sprintf(
#   "v0.2.0: EN = %.1f (after %d evals)",
#   min(fit_old$history$objective[fit_old$history$feasible]),
#   nrow(fit_old$history)
# ))
# message(sprintf(
#   "v0.3.0: EN = %.1f (after %d evals)",
#   min(fit_new$history$objective[fit_new$history$feasible]),
#   nrow(fit_new$history)
# ))

## ----troubleshoot-early-stop, eval=FALSE--------------------------------------
# # Current implementation uses:
# #   - Patience: 10 iterations
# #   - Improvement threshold: 0.01%
# #   - Requires: 2 consecutive patience windows
# 
# # Workaround: Increase budget to account for early stopping
# # If you want ~50 evaluations after early stopping, set budget = 70
# 
# fit <- bo_calibrate(..., budget = 70)

## ----troubleshoot-diversity, eval=FALSE---------------------------------------
# # Lipschitz constant is estimated from GP lengthscales
# # If points still cluster, your acquisition landscape may have
# # very sharp peaks
# 
# # Try: Larger initial design for better lengthscale estimation
# fit <- bo_calibrate(..., n_init = 6 * length(bounds))

## ----troubleshoot-fidelity, eval=FALSE----------------------------------------
# # Specify custom costs to encourage higher fidelity
# fit <- bo_calibrate(
#   ...,
#   fidelity_costs = c(low = 1, med = 2, high = 10)  # Less than default 1:5:50
# )
# 
# # Or use staged method for predictable fidelity progression
# fit <- bo_calibrate(..., fidelity_method = "staged")

## ----session-info-------------------------------------------------------------
sessionInfo()

