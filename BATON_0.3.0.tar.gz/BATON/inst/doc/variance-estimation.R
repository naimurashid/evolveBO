## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)

## ----eval=FALSE---------------------------------------------------------------
# # Traditional approach - stores everything
# n_rep <- 10000
# results <- matrix(NA, nrow = n_rep, ncol = 4)  # 320 KB!
# 
# for (i in 1:n_rep) {
#   results[i, ] <- run_trial(theta)
# }
# 
# mean_vec <- colMeans(results)
# var_vec <- apply(results, 2, var) / n_rep

## -----------------------------------------------------------------------------
library(BATON)

# Welford's algorithm in action
set.seed(123)

result <- welford_mean_var(
  sample_fn = function(i) {
    # Simulate one observation
    c(
      x = rnorm(1, mean = 5, sd = 2),
      y = runif(1, min = 0, max = 1)
    )
  },
  n_samples = 1000
)

print(result)

## -----------------------------------------------------------------------------
my_simulator <- function(theta, fidelity = "high", seed = NULL, ...) {
  # Determine number of replications
  n_rep <- switch(fidelity,
                  low = 200,
                  med = 1000,
                  high = 10000)

  if (!is.null(seed)) set.seed(seed)

  # Use welford_mean_var for efficiency
  result <- welford_mean_var(
    sample_fn = function(i, theta) {
      # Your trial simulation here (returns ONE sample)
      test_stat <- rnorm(1, mean = theta$effect, sd = 1)
      reject <- abs(test_stat) > qnorm(0.975)

      n_patients <- rpois(1, lambda = theta$sample_size_mean)

      c(
        power = as.numeric(reject),
        EN = n_patients,
        ET = n_patients / 10  # Expected duration
      )
    },
    n_samples = n_rep,
    theta = theta
  )

  # Return metrics with variance attribute
  metrics <- result$mean
  attr(metrics, "variance") <- result$variance
  attr(metrics, "n_rep") <- result$n

  return(metrics)
}

# Test it
test <- my_simulator(
  theta = list(effect = 2.0, sample_size_mean = 100),
  fidelity = "low",
  seed = 456
)

cat("Metrics:\n")
print(test)
cat("\nVariance:\n")
print(attr(test, "variance"))

## ----eval=FALSE---------------------------------------------------------------
# my_parallel_simulator <- function(theta,
#                                   fidelity = "high",
#                                   n_cores = 4,
#                                   seed = NULL,
#                                   ...) {
#   n_rep <- switch(fidelity, low = 200, med = 1000, high = 10000)
#   chunk_size <- ceiling(n_rep / n_cores)
# 
#   # Set up parallel RNG
#   if (!is.null(seed)) {
#     RNGkind("L'Ecuyer-CMRG")
#     set.seed(seed)
#   }
# 
#   # Run chunks in parallel
#   library(parallel)
#   chunk_results <- mclapply(1:n_cores, function(core_id) {
#     # Each core computes its own mean and variance
#     welford_mean_var(
#       sample_fn = function(i, theta) {
#         # Your simulation here
#         c(power = ..., EN = ...)
#       },
#       n_samples = chunk_size,
#       theta = theta
#     )
#   }, mc.cores = n_cores)
# 
#   # Pool results from all cores
#   pooled <- pool_welford_results(chunk_results)
# 
#   metrics <- pooled$mean
#   attr(metrics, "variance") <- pooled$variance
#   attr(metrics, "n_rep") <- pooled$n
# 
#   return(metrics)
# }

## -----------------------------------------------------------------------------
my_manual_simulator <- function(theta, fidelity = "high", ...) {
  n_rep <- switch(fidelity, low = 200, med = 1000, high = 10000)

  # Initialize Welford accumulators
  n_metrics <- 3
  mean_vec <- numeric(n_metrics)
  M2_vec <- numeric(n_metrics)

  for (i in 1:n_rep) {
    # Simulate one trial
    x <- c(
      power = rbinom(1, 1, prob = 0.8),
      EN = rpois(1, 100),
      ET = rnorm(1, 10, 2)
    )

    # Welford update
    delta <- x - mean_vec
    mean_vec <- mean_vec + delta / i
    delta2 <- x - mean_vec
    M2_vec <- M2_vec + delta * delta2
  }

  # Finalize variance
  variance <- M2_vec / (n_rep * (n_rep - 1))

  names(mean_vec) <- names(variance) <- c("power", "EN", "ET")
  attr(mean_vec, "variance") <- variance
  attr(mean_vec, "n_rep") <- n_rep

  return(mean_vec)
}

# Test manual implementation
manual_test <- my_manual_simulator(
  theta = list(dummy = 1),
  fidelity = "low"
)

print(manual_test)

## -----------------------------------------------------------------------------
library(BATON)

# Simple test simulator
test_sim <- function(theta, fidelity = "high", use_variance = TRUE, ...) {
  n_rep <- 200  # Small for demo

  if (use_variance) {
    # With Welford
    result <- welford_mean_var(
      sample_fn = function(i, theta) {
        c(
          power = rbinom(1, 1, 0.8),
          EN = rnorm(1, theta$x * 100, 20)
        )
      },
      n_samples = n_rep,
      theta = theta
    )
    metrics <- result$mean
    attr(metrics, "variance") <- result$variance
  } else {
    # Without variance (will use nugget)
    power_samples <- rbinom(n_rep, 1, 0.8)
    en_samples <- rnorm(n_rep, theta$x * 100, 20)

    metrics <- c(
      power = mean(power_samples),
      EN = mean(en_samples)
    )
    # No variance attribute!
  }

  return(metrics)
}

# Test both approaches
with_var <- test_sim(list(x = 1), use_variance = TRUE)
without_var <- test_sim(list(x = 1), use_variance = FALSE)

cat("With variance:\n")
print(with_var)
print(attr(with_var, "variance"))

cat("\nWithout variance:\n")
print(without_var)
cat("variance attribute:", attr(without_var, "variance"), "\n")

## -----------------------------------------------------------------------------
# Memory comparison
cat("Memory usage comparison:\n")
cat("Traditional (store all):", 8 * 10000 * 4, "bytes =", 8 * 10000 * 4 / 1024, "KB\n")
cat("Welford (incremental): ", 8 * 2 * 4, "bytes\n")
cat("Reduction factor:      ", (8 * 10000 * 4) / (8 * 2 * 4), "x\n\n")

# Speed overhead
library(microbenchmark)

# Benchmark Welford overhead
benchmark <- microbenchmark(
  welford = {
    result <- welford_mean_var(
      sample_fn = function(i) c(x = rnorm(1), y = runif(1)),
      n_samples = 1000
    )
  },
  naive = {
    results <- replicate(1000, c(x = rnorm(1), y = runif(1)))
    mean_vec <- rowMeans(results)
    var_vec <- apply(results, 1, var) / 1000
  },
  times = 10
)

print(summary(benchmark)[, c("expr", "mean", "median")])

## -----------------------------------------------------------------------------
adaptive_trial_simulator <- function(theta,
                                     fidelity = c("low", "med", "high"),
                                     seed = NULL,
                                     ...) {
  fidelity <- match.arg(fidelity)
  n_rep <- switch(fidelity, low = 200, med = 1000, high = 10000)

  if (!is.null(seed)) set.seed(seed)

  result <- welford_mean_var(
    sample_fn = function(i, theta) {
      # Simulate adaptive two-arm trial
      n_per_arm <- 50
      control <- rnorm(n_per_arm, mean = 0, sd = 1)
      treatment <- rnorm(n_per_arm, mean = theta$treatment_effect, sd = 1)

      # Interim analysis
      interim_p <- t.test(treatment[1:20], control[1:20])$p.value
      stop_early <- interim_p < theta$futility_threshold

      if (stop_early) {
        total_n <- 40  # Stopped early
        reject <- FALSE
      } else {
        total_n <- 100  # Continued to full sample
        final_p <- t.test(treatment, control)$p.value
        reject <- final_p < 0.025
      }

      # Calculate duration (months)
      enrollment_rate <- 5  # patients per month
      duration <- total_n / enrollment_rate

      c(
        power = as.numeric(reject),
        type1 = 0,  # Under H0 scenario
        EN = total_n,
        ET = duration,
        early_stop_rate = as.numeric(stop_early)
      )
    },
    n_samples = n_rep,
    theta = theta
  )

  metrics <- result$mean
  attr(metrics, "variance") <- result$variance
  attr(metrics, "n_rep") <- result$n

  return(metrics)
}

# Run calibration with this simulator
bounds <- list(
  treatment_effect = c(0.3, 0.8),
  futility_threshold = c(0.1, 0.5)
)

# Note: Commented out to avoid long vignette build time
# fit <- bo_calibrate(
#   sim_fun = adaptive_trial_simulator,
#   bounds = bounds,
#   objective = "EN",
#   constraints = list(power = c("ge", 0.8)),
#   n_init = 10,
#   budget = 30
# )

## ----eval=FALSE---------------------------------------------------------------
# # BAD - inconsistent output
# sample_fn = function(i, theta) {
#   if (i == 1) return(c(power = 0.8))  # 1 metric
#   else return(c(power = 0.8, EN = 100))  # 2 metrics - ERROR!
# }
# 
# # GOOD - always same metrics
# sample_fn = function(i, theta) {
#   c(power = 0.8, EN = 100)  # Always 2 metrics
# }

## ----eval=FALSE---------------------------------------------------------------
# # Check your simulator output
# test <- sample_fn(1, theta)
# stopifnot(all(is.finite(test)))

## ----eval=FALSE---------------------------------------------------------------
# # Each chunk should return proper structure
# chunk <- welford_mean_var(...)
# stopifnot(all(c("mean", "variance", "n") %in% names(chunk)))

## ----eval=FALSE---------------------------------------------------------------
# attr(metrics, "variance") <- result$variance

## ----eval=FALSE---------------------------------------------------------------
# # Basic template
# my_sim <- function(theta, fidelity = "high", seed = NULL, ...) {
#   n_rep <- switch(fidelity, low = 200, med = 1000, high = 10000)
#   if (!is.null(seed)) set.seed(seed)
# 
#   result <- welford_mean_var(
#     sample_fn = function(i, theta) {
#       # YOUR SIMULATION HERE
#       c(metric1 = ..., metric2 = ...)
#     },
#     n_samples = n_rep,
#     theta = theta
#   )
# 
#   metrics <- result$mean
#   attr(metrics, "variance") <- result$variance
#   attr(metrics, "n_rep") <- result$n
#   return(metrics)
# }

## -----------------------------------------------------------------------------
sessionInfo()

